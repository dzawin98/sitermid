<?php

class M_auth extends CI_Model {

	public function login($username,$password) {
		
		$query=$this->db->query("SELECT * FROM master_user a inner join master_institusi b on a.InstitusiID=b.InstitusiID inner join master_usergroup c on a.UserGroupID = c.UserGroupID WHERE a.UserID='$username' AND a.Password=MD5('$password') AND a.NA='N';");
        return $query;
	}

	public function get_dokter($dokterid) {
		
		$query=$this->db->query("SELECT * FROM master_dokter where DokterID = '$dokterid';");
        return $query;
	}

}
?>