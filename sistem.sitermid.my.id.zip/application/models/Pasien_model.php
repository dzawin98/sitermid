<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien_model extends CI_Model {
    
    // Fungsi untuk menambahkan data pasien ke database
    public function tambah_pasien($data) {
        return $this->db->insert('pasien', $data);
    }

    // Fungsi untuk mengambil semua data pasien dari database
    public function get_all_pasien() {
        $query = $this->db->get('pasien');
        return $query->result();
    }
}
