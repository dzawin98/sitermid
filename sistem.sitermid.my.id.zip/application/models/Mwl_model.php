<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mwl_model extends CI_Model {

    private $orthanc_url = 'http://localhost:8042/worklists'; // Sesuaikan dengan URL Orthanc

    // Fungsi untuk menambah worklist ke Orthanc MWL Server
    public function tambah_worklist($data) {
        $payload = array(
            "00100010" => array("vr" => "PN", "Value" => array($data['nama'])),
            "00100020" => array("vr" => "LO", "Value" => array($data['no_rm'])),
            "00100030" => array("vr" => "DA", "Value" => array($data['tanggal_lahir'])),
            "00100040" => array("vr" => "CS", "Value" => array($data['jenis_kelamin'])),
            "00400001" => array("vr" => "AE", "Value" => array("RIS")),
            "00400009" => array("vr" => "SH", "Value" => array($data['accession_number'])),
            "00401001" => array("vr" => "SH", "Value" => array($data['jenis_pemeriksaan']))
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->orthanc_url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response);
    }
}
