<?php
class M_admin extends CI_Model {

    function getStudies($serverURL) {
        $orthancApiUrl = $serverURL.'studies';
        $orthancUsername = ''; // If authentication is enabled
        $orthancPassword = '';

        // Prepare cURL request
        $ch = curl_init();

        // Set the API endpoint URL
        curl_setopt($ch, CURLOPT_URL, $orthancApiUrl);

        // Set authentication credentials if needed
        if (!empty($orthancUsername) && !empty($orthancPassword)) {
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, "$orthancUsername:$orthancPassword");
        }

        // Execute the cURL request
        $response = curl_exec($ch);

        // Check for cURL errors
        if (curl_errno($ch)) {
            echo 'Error fetching studies: ' . curl_error($ch);
            return array(); // Return an empty array on error
        }

        // Decode the JSON response
        $studies = json_decode($response, true);

        // Close cURL session
        curl_close($ch);

        return $studies;
    }

	function cek_akses($usergroupid,$moduleid) {
		$query = $this->db->query("SELECT * FROM `master_hak_akses` a, master_module b  WHERE a.ModuleID=b.ModuleID and a.UserGroupID LIKE '$usergroupid' AND a.ModuleID LIKE '$moduleid' AND a.NA='N'");
		return $query;
	}

	function get_menu($usergroupid) {
		$query = $this->db->query("SELECT * FROM master_usergroup a, master_hak_akses b, master_module c WHERE a.UserGroupID=b.UserGroupID AND b.ModuleID=c.ModuleID AND a.UserGroupID = '$usergroupid' AND b.NA = 'N' AND c.NA = 'N' order by c.NoModule asc");
		return $query;
	}

    function get_dokter_rad() {
        $query = $this->db->query("SELECT * FROM master_dokter where NA ='N'");
        return $query;
    }

    function get_all_dokter() {
        $query = $this->db->query("SELECT * FROM master_dokter");
        return $query;
    }

    function get_all_user() {
        $query = $this->db->query("SELECT a.UserID, a.NamaUser, a.UserGroupID, b.NamaUserGroup, a.NA  FROM master_user a, master_usergroup b where a.UserGroupID = b.UserGroupID");
        return $query;
    }

    function get_all_usergroup() {
        $query = $this->db->query("SELECT *  FROM master_usergroup");
        return $query;
    }

    function get_all_module() {
        $query = $this->db->query("SELECT *  FROM master_module");
        return $query;
    }

    function get_all_hakakses() {
        $query = $this->db->query("SELECT *, a.NA as Status FROM master_hak_akses a, master_usergroup b, master_module c where a.UserGroupID = b.UserGroupID and a.ModuleID = c.ModuleID order by a.UserGroupID desc");
        return $query;
    }

    function get_pacs_server() {
        $query = $this->db->query("SELECT * FROM pacs_server where NA = 'N'");
        return $query;
    }

    function simpan_data($tabel,$data) {
        $this->db->insert($tabel,$data);
    }

    function update_data($table, $field_id, $id, $data) {
        $this->db->where($field_id, $id);
        $this->db->update($table, $data);
    }

    function get_status_expertise($StudyID) {
        $query = $this->db->query("SELECT Status FROM trx_study where StudyID = '$StudyID'");
        return $query->row();
    }

    function get_study_stored() {
        $query = $this->db->query("select StudyID from trx_study where NA = 'N'");
        return $query;
    }

    function get_template($DokterID) {
        $query = $this->db->query("select * from master_template where DokterID ='$DokterID' AND NA = 'N'");
        return $query;
    }

    function get_all_template($DokterID) {
        $query = $this->db->query("select * from master_template where DokterID = '$DokterID'");
        return $query;
    }

    function get_trx_study() {
        $query = $this->db->query("select * from trx_study a inner join master_dokter b on a.DokterID = b.DokterID where a.NA = 'N' order by a.TanggalBuat desc");
        return $query;
    }

    function get_trx_study_bydokter($DokterID) {
        $query = $this->db->query("select * from trx_study a inner join master_dokter b on a.DokterID = b.DokterID where a.NA = 'N' AND a.DokterID = '$DokterID' order by a.TanggalBuat desc");
        return $query;
    }

    function get_detail_study($StudyID) {
        $query = $this->db->query("select * from trx_study a inner join master_dokter b on a.DokterID = b.DokterID where a.NA = 'N' and a.StudyID = '$StudyID'");
        return $query->row();
    }

    function get_detail_dokter($DokterID) {
        $query = $this->db->query("select * from master_dokter where DokterID = '$DokterID'");
        return $query->row();
    }

    function get_detail_expertise($StudyID) {
        $query = $this->db->query("select * from trx_expertise where NA = 'N' and StudyID = '$StudyID' and Final = 'Y'");
        return $query->row();
    }

    function get_trx_expertise($StudyID) {
        $query = $this->db->query("select * from trx_expertise where NA = 'N' and StudyID = '$StudyID' order by RevisionNo asc");
        return $query;
    }

    function cek_duplikasi($id, $field_id, $table) {
        $query = $this->db->query("select * from $table where $field_id = '$id'");
        return $query->row();
    } 

    function getModulesNotInAccessRole($usergroupid){
        $query = $this->db->query("SELECT a.ModuleID, a.NamaModule FROM master_module a WHERE a.NA = 'N' AND a.ModuleID NOT IN (SELECT b.ModuleID from master_hak_akses b WHERE UserGroupID = '$usergroupid')");
        return $query;
    }

    function get_institusi($InstitusiID) {
        $query = $this->db->query("select * from master_institusi where InstitusiID = '$InstitusiID'");
        return $query;
    }

    function get_jumlah_expertise($Status, $DokterID) {
        $query = $this->db->query("select count(StudyID) as Jumlah from trx_study where Status = '$Status' AND DokterID = '$DokterID'");
        return $query;
    }

    function get_jumlah_all_expertise($Status) {
        $query = $this->db->query("select count(StudyID) as Jumlah from trx_study where Status = '$Status'");
        return $query;
    }

    function getDataInstitusi($InstitusiID) {
        $query = $this->db->query("select * from master_institusi where InstitusiID = '$InstitusiID'");
        return $query->row();
    }

}
?>