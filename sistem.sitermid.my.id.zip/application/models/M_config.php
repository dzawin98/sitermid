<?php

class M_config extends CI_Model
{

public function config()
	{
		
		$query = $this->db->query("select * from master_config where NA='N'");
		return $query->row();
	}

}
?>