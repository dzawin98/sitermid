<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orthanc_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function getStudyIDs() {
        $orthancApiUrl = 'http://localhost:8042/studies';
        $orthancUsername = 'your-username'; // If authentication is enabled
        $orthancPassword = 'your-password';

        // Prepare cURL request
        $ch = curl_init();

        // Set the API endpoint URL
        curl_setopt($ch, CURLOPT_URL, $orthancApiUrl);

        // Set authentication credentials if needed
        if (!empty($orthancUsername) && !empty($orthancPassword)) {
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, "$orthancUsername:$orthancPassword");
        }

        // Execute the cURL request
        $response = curl_exec($ch);

        // Check for cURL errors
        if (curl_errno($ch)) {
            echo 'Error fetching study IDs: ' . curl_error($ch);
            return array(); // Return an empty array on error
        }

        // Decode the JSON response
        $studyIDs = json_decode($response, true);

        // Close cURL session
        curl_close($ch);

        return $studyIDs;
    }

    public function getStudyDetails($studyID) {
        $orthancApiUrl = "http://localhost:8042/studies/{$studyID}";
        $orthancUsername = ''; // If authentication is enabled
        $orthancPassword = '';

        // Prepare cURL request
        $ch = curl_init();

        // Set the API endpoint URL
        curl_setopt($ch, CURLOPT_URL, $orthancApiUrl);

        // Set authentication credentials if needed
        if (!empty($orthancUsername) && !empty($orthancPassword)) {
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, "$orthancUsername:$orthancPassword");
        }

        // Execute the cURL request
        $response = curl_exec($ch);

        // Check for cURL errors
        if (curl_errno($ch)) {
            echo 'Error fetching study details: ' . curl_error($ch);
            return array(); // Return an empty array on error
        }

        // Decode the JSON response
        $studyDetails = json_decode($response, true);

        // Close cURL session
        curl_close($ch);

        return $studyDetails;
    }
}
