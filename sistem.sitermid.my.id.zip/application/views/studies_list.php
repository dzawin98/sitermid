<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DICOM Studies List</title>
</head>
<body>

<h1>DICOM Studies List</h1>

<?php if (is_array($studies) && !empty($studies)): ?>
    <table border="1">
        <thead>
            <tr>
                <th>Patient ID</th>
                <th>Patient Name</th>
                <th>Patient Birthday</th>
                <th>Study Description</th>
                <th>Study ID</th>
                <th>Modality</th>
                <th>Study Date</th>
                <th>Study UID</th>
                <th>Number of Series</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($studies as $study): ?>
                <tr>
                    <td><?php echo $study['MainDicomTags']['PatientID']; ?></td>
                    <td><?php echo $study['MainDicomTags']['PatientName']; ?></td>
                    <td><?php echo $study['MainDicomTags']['PatientBirthDate']; ?></td>
                    <td><?php echo $study['MainDicomTags']['StudyDescription']; ?></td>
                    <td><?php echo $study['MainDicomTags']['StudyID']; ?></td>
                    <td><?php echo $study['MainDicomTags']['ModalitiesInStudy']; ?></td>
                    <td><?php echo $study['MainDicomTags']['StudyDate']; ?></td>
                    <td><?php echo $study['MainDicomTags']['StudyInstanceUID']; ?></td>
                    <td><?php echo count($study['Series']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No DICOM studies found.</p>
<?php endif; ?>

</body>
</html>
