<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $config->HeadTittle;?></title>
  
  <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body style="background-color: #ffffff;">

  <!-- ======= Header ======= -->
  
<!-----------------------------------------isi------------------->

<div>
  <font size="14px"><b><?= $detail_institusi->NamaInstitusi;?></b></font><br>
  <font size="12px"><?= $detail_institusi->Alamat;?></font>
</div>

<div>
  <h3 align="center">Hasil Expertise</h3>
</div>

<table width="100%" border ="0px">
  <tr>
    <td width="30%"> Nama Pasien / No RM</td>
    <td width="2%">:</td>
    <td width="68%"><?= $detail_study->Pasien;?> / <?= $detail_study->MR;?></td>
  </tr>
  <?php
    if($detail_study->TglLahir != null && $detail_study->TglPemeriksaan != null) {
      $string1 = $detail_study->TglLahir;
      $date1 = DateTime::createFromFormat('Ymd', $string1);
      $TglLahir = $date1->format('d-m-Y');
      
      $string2 = $detail_study->TglPemeriksaan;
      $date2 = DateTime::createFromFormat('Ymd', $string2);
      $TglPemeriksaan = $date2->format('d-m-Y');
      
      $interval = $date1->diff($date2);
      $years = $interval->y;
      $months = $interval->m;
    } else {
      $TglLahir = '';
      $TglPemeriksaan = '';
      $years = 0;
      $months = 0;
    }
  ?>
  <tr>
    <td width="30%"> Tanggal Lahir / Umur</td>
    <td width="2%">:</td>
    <td width="68%"><?= $TglLahir;?> / <?= $years." Tahun ".$months." Bulan";?></td>
  </tr>
  <tr>
    <td width="30%"> Tanggal Pemeriksaan / Acc No</td>
    <td width="2%">:</td>
    <td width="68%"><?= $TglPemeriksaan;?> / <?= $detail_study->AccNo;?></td>
  </tr>
  <tr>
    <td width="30%"> Jenis Pemeriksaan / Modalitas</td>
    <td width="2%">:</td>
    <td width="68%"><?= $detail_study->Deskripsi;?> / <?= $detail_study->Modalitas;?></td>
  </tr>
  <tr>
    <td colspan="3"><hr style="height:0.7px;border:none;color:#333;background-color:#333;"></td>
  </tr>
  <tr>
    <td colspan="3"><br><div style="line-height: 0.4;"><?= $detail_expertise->Expertise ?? null;?></div></td>
  </tr>

</table>

<?php
  if(isset($detail_expertise->TanggalBuat)) {
    $string = $detail_expertise->TanggalBuat; // Your date string
    $formattedDate = date('d-m-Y', strtotime($string));
  } else $formattedDate ='';
?>

<table width="100%">
  <tr>
    <td align="right">
      <div style="line-height: 0.5;">
        <?= $detail_institusi->Kota;?>, <?= $formattedDate;?>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <?= $detail_study->NamaDokter;?>
      </div>
    </td>
  </tr>
</table>
              
              <hr style="height:0.7px;border:none;color:#333;background-color:#333;">
              <font size="10px">Dokumen ini digenerate otomatis melalui aplikasi <?php echo $config->HeadTittle;?><br>
                <a href="<?= base_url();?>"><?= base_url();?></a>
              </font><br>

</body>

</html>