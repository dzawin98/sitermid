<main id="main" class="main">

    <div class="pagetitle">
      <h1><?php echo $module_detail;?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin">Home</a></li>
          <li class="breadcrumb-item">Admin</li>
          <li class="breadcrumb-item active"><?php echo $module_detail;?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h2 class="card-title">Data Dokter</h2>
              <form>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"><button data-bs-toggle="modal" data-bs-target="#addDokter" type="button" class="btn btn-info btn-sm"><i class="bi bi-plus"></i>Tambah Dokter</button></label>
                </div>
              </form>
              <hr>
              <div class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns">
                <div class="datatable-top">
                  <table class="table datatable datatable-table">
                    <thead>
                      <tr>
                        <th>DokterID</th>
                        <th>Nama Dokter</th>
                        <th>No SIP</th>
                        <th>TMT SIP</th>
                        <th>TAT SIP</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($Dokter->result() as $dataDokter) { ?>
                      <tr>
                        <td><?= $dataDokter->DokterID;?></td>
                        <td><?= $dataDokter->NamaDokter;?></td>
                        <td><?= $dataDokter->NoSIP;?></td>
                        <td><?= date_format(date_create($dataDokter->SIPDateActive),'d-m-Y');?></td>
                        <td><?= date_format(date_create($dataDokter->SIPDateExpired),'d-m-Y');?></td>
                        <td>
                          <?php if($dataDokter->NA =='Y') {?>
                            <span class="badge bg-secondary">Not Active</span>
                          <?php } ?>
                          <?php if($dataDokter->NA =='N') {?>
                            <span class="badge bg-info">Active</span>
                          <?php } ?>  
                          </td>
                        <td>
                            <a href="<?php echo base_url();?>admin/editdokter?id=<?= $dataDokter->DokterID;?>">
                              <button type="button" title="Edit data Dokter" class="btn btn-primary btn-sm">
                                <i class="bi bi-pencil-square"></i>
                              </button>
                            </a>
                            <a href="<?php echo base_url();?>admin/datadokter?id=<?= $dataDokter->DokterID;?>">
                              <button type="button" title="View Detail" class="btn btn-secondary btn-sm">
                                <i class="bi bi-list"></i>
                              </button>
                            </a>
                          </td>
                      </tr>
                    <?php } ?>
                    </tbody>

                    
                    
                  </table>
                </div>
              </div>
              <div class="modal fade" id="addDokter" tabindex="-1">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <form action="<?= base_url();?>admin/simpan_dokter" method="post">
                      <div class="modal-header">
                        <h5 class="modal-title">Tambah Dokter</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Dokter ID</label>
                          <div class="col-sm-8">
                            <input type="text" name="DokterID" placeholder="3 digit inisial" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Nama Dokter</label>
                          <div class="col-sm-8">
                            <input type="text" name="NamaDokter" value="" placeholder="Nama Lengkap dan Gelar" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">NIK</label>
                          <div class="col-sm-8">
                            <input type="text" name="NIK" value="" placeholder="NIK KTP" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">No SIP</label>
                          <div class="col-sm-8">
                            <input type="text" name="NoSIP" value="" placeholder="Surat Izin Praktek" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                           <label for="inputEmail3" class="col-sm-3 col-form-label">Tanggal Berlaku</label>
                          <div class="col-sm-8">
                            <input type="date" name="SIPDateActive" value="" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Tanggal Berakhir</label>
                          <div class="col-sm-8">
                            <input type="date" name="SIPDateExpired" value="" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Status Akun</label>
                          <div class="col-sm-6">
                            <select class="form-select" aria-label="Default select example" name="NA" required>
                              <option value="N" selected="">Aktif</option>
                              <option value="Y">Tidak Aktif</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" value="Simpan">
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      Copyright <?php echo $config->CopyrightYear;?> <strong><span><?php echo $config->UserOrganization;?></span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="<?php echo $config->DeveloperWeb;?>"><?php echo $config->Developer;?></a>
    </div>
  </footer><!-- End Footer --><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url() ?>assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/chart.js/chart.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/echarts/echarts.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/quill/quill.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url() ?>assets/js/main.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>assets/js/signature.js"></script>
  <script>
    var wrapper = document.getElementById("signature-pad");
    var clearButton = wrapper.querySelector("[data-action=clear]");
    var savePNGButton = wrapper.querySelector("[data-action=save-png]");
    var canvas = wrapper.querySelector("canvas");
    var el_note = document.getElementById("note");
    var signaturePad;
    signaturePad = new SignaturePad(canvas);
    clearButton.addEventListener("click", function (event) {
      document.getElementById("note").innerHTML="The signature should be inside box";
      signaturePad.clear();
    });
    savePNGButton.addEventListener("click", function (event){
      if (signaturePad.isEmpty()){
        alert("Please provide signature first.");
        event.preventDefault();
      }else{
        var canvas  = document.getElementById("the_canvas");
        var dataUrl = canvas.toDataURL();
        document.getElementById("signature").value = dataUrl;
      }
    });
    function my_function(){
      document.getElementById("note").innerHTML="";
    }
</script>

</body>

</html>