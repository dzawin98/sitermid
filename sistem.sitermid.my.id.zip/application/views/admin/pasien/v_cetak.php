<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $config->HeadTittle;?></title>
  
  <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body style="background-color: #ffffff;">

  <!-- ======= Header ======= -->
  
<!-----------------------------------------isi------------------->
<div>
  <h2 align="center"><?php echo $module_detail->NamaToolsAudit;?></h2>
</div>
<br>
<?php foreach ($struktur_audit->result() as $data_struktur) {?>
              <?php foreach ($trxaudit as $trxauditid => $audit) {?>
                <div class="col-12">
                  <input type="hidden" name="toolsauditid" value="A" class="form-control" id="inputName9">
                </div>

                <!-- Tanggal Audit -->
                <?php if($data_struktur->TanggalAudit == 'Y') { ?>
                <div class="col-12">
                  <label for="inputName1" class="form-label" ><b>Tanggal Audit :</label>
                  <?php echo $audit->TanggalAudit; ?>
                </div>

                <?php } ?>
                <!-- Akhir Tanggal Audit -->

                <!-- Departemen -->
                <?php if($data_struktur->Departemen == 'Y') { ?>
                <div class="col-12">
                  <label for="inputName2" class="form-label"><b>Departemen :</label>
                  <?php echo $audit->NamaDepartemen; ?>
                </div>
                <?php } ?>
                <!-- Akhir Departemen -->

                <!-- Profesi -->
                <?php if($data_struktur->Profesi == 'Y') { ?>
                <div class="col-12">
                  <label for="inputName2" class="form-label"><b>Profesi :</label>
                  <?php echo $audit->NamaProfesi; ?>
                </div>
                <?php } ?>
                <!-- Akhir Profesi -->

                <!-- Indikasi APD -->
                <?php if($data_struktur->IndikasiAPD == 'Y') { ?>
                <div class="col-12">
                  <label for="inputName2" class="form-label"><b>Indikasi Pemakaian APD :</label>
                  <?php echo $audit->NamaIndikasi; ?>
                </div>
                <?php } ?>
                <!-- Akhir Indikasi APD -->

                <!-- Jenis Tindakan -->
                <?php if($data_struktur->JenisTindakan == 'Y') { ?>
                <div class="col-12">
                  <label for="inputName2" class="form-label"><b>Jenis Tindakan :</label>
                  <?php echo $audit->JenisTindakan; ?>
                </div>
                <?php } ?>
                <!-- Akhir Jenis Tindakan -->

                <!-- IDO -->
                <?php if($data_struktur->BundleIDO == 'Y') { ?>
                
                  <?php } ?>
                  <?php if($data_struktur->Medrec == 'Y') { ?>
                <div class="col-12">
                  <label for="inputName2" class="form-label"><b>No. Rekam Medis :</label>
                  <?php echo $audit->MedRec; ?>
                </div>
                <?php } ?>
                  <?php if($data_struktur->NamaPasien == 'Y') { ?>
                <div class="col-12">
                  <label for="inputName2" class="form-label"><b>Nama Pasien :</label>
                  <?php echo $audit->NamaPasien; ?>
                </div>
                <?php } ?>
                <!-- Akhir IDO -->


              <!-- Default Table -->

              <hr style="height:0.7px;border:none;color:#333;background-color:#333;">
              <table class="table">
                <tbody>
                  <?php
                  $no=1;
                  foreach ($trxaudit_detail as $detailid => $value) {?>
                  <tr>
                    <td><?php if($value->Header=='Y') echo "<b>".$value->NamaToolsAudit."</b>"; else echo $value->NamaToolsAudit;?></td>
                    <td>
                      <?php if($value->Header=='N') {
                        if ($value->Value=='Y') echo 'Ya';
                        else if ($value->Value=='N') echo 'Tidak';
                        else echo 'NA';
                      } else { 
                        echo "<b>Hasil Audit</b>";
                      }?>
                    </td>
                    <td>
                      <?php if($value->Header=='N') {
                          if($value->Dokumentasi!='')
                            echo "<a href='".base_url().$value->Dokumentasi."' target='_blank'><span class='badge bg-success'><i class='bi bi-eye me-1'></i> View</span></a>";
                          else echo "-";
                      } else { 
                        echo "<b>Dokumentasi</b>";
                      }?>
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>

              <hr style="height:0.7px;border:none;color:#333;background-color:#333;">

              <!-- IDO -->
              <?php if($data_struktur->BundleIDO == 'Y') { ?>
              <div class="col-12">
                <label for="inputName1" class="form-label" ><b>Tanggal Operasi :</b></label>
                  <?php echo $audit->TanggalOP; ?>
              </div>
              <div class="col-12">
                <label for="inputName2" class="form-label"><b>Perlu Monitoring? :</b></label><br>
                <?php if($audit->Monitoring=='0') echo 'Tidak Perlu'; else if ($audit->Monitoring=='30') echo 'Perlu, 30 Hari'; else if ($audit->Monitoring=='90') echo 'Perlu, 90 Hari'; else echo ''; ?>
              </div>
              <?php } ?>
                <!-- Akhir IDO -->

              <!-- Catatan -->
              <?php if($data_struktur->Catatan == 'Y') { ?>
              <div class="col-12">
                <input type="hidden" name="jumlahform" class="form-control" value="<?php echo $no;?>" required>
                <label for="inputName11" class="form-label"><b>Catatan Audit :</b></label><br>
                <?php echo $audit->Catatan;?>
              </div>
              <?php } ?>
              <!-- Akhir Catatan -->

              <!-- Petugas Diaudit -->
              <?php if($data_struktur->PetugasDiaudit == 'Y') { ?>
              <hr style="height:0.7px;border:none;color:#333;background-color:#333;">
              <div class="col-12">
                <label for="inputName10" class="form-label"><b>Petugas Ruangan yang Diaudit :</b></label>
              <?php } ?>
              <!-- Akhir Petugas Diaudit -->

              <!-- Tanda Tangan -->
              <?php if($data_struktur->PetugasDiaudit == 'Y') { ?>
                
              </div>
              <div class="col-4">
                <?php if($data_struktur->TandaTangan == 'Y') { ?>
                <img src="<?php echo base_url().$audit->TandaTangan?>"><br>
                <?php } ?>
                <?php echo $audit->PetugasDiaudit;?>
              </div>
              <?php } ?>
              <!-- Akhir Tanda Tangan -->

              <hr style="height:0.7px;border:none;color:#333;background-color:#333;">
              <div class="col-12">
                <label for="inputName11" class="form-label">Audit Dilakukan Oleh: <?php echo $audit->NamaUser;?></label>
                <br>
                <label for="inputName11" class="form-label">Pada Tanggal: <?php echo $audit->TanggalBuat;?></label>
              </div>
              <hr style="height:0.7px;border:none;color:#333;background-color:#333;">
              <font size="10px">Dokumen ini digenerate otomatis melalui aplikasi <?php echo $config->HeadTittle;?><br>
                <a href="<?= base_url();?>"><?= base_url();?></a>
              </font><br>
              <?php } ?>
              <?php } ?>

</body>

</html>