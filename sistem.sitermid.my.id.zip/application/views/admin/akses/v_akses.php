<main id="main" class="main">

    <div class="pagetitle">
      <h1><?php echo $module_detail;?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin">Home</a></li>
          <li class="breadcrumb-item">Admin</li>
          <li class="breadcrumb-item active"><?php echo $module_detail;?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <!-- User -->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h2 class="card-title">Data User</h2>
              <form>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"><button data-bs-toggle="modal" data-bs-target="#addUser" type="button" class="btn btn-info btn-sm"><i class="bi bi-plus"></i>Tambah User</button></label>
                </div>
              </form>
              <hr>
              <div class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns">
                <div class="datatable-top">
                  <table class="table datatable datatable-table">
                    <thead>
                      <tr>
                        <th>Username / Email</th>
                        <th>Nama</th>
                        <th>UserGroup</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($User->result() as $dtForeach) { ?>
                      <tr>
                        <td><?= $dtForeach->UserID;?></td>
                        <td><?= $dtForeach->NamaUser;?></td>
                        <td><?= $dtForeach->NamaUserGroup;?></td>
                        <td>
                          <?php if($dtForeach->NA =='Y') {?>
                            <span class="badge bg-secondary">Not Active</span>
                          <?php } ?>
                          <?php if($dtForeach->NA =='N') {?>
                            <span class="badge bg-info">Active</span>
                          <?php } ?>  
                          </td>
                        <td>
                            <a href="<?php echo base_url();?>admin/edituser?id=<?= $dtForeach->UserID;?>">
                              <button type="button" title="Edit data Dokter" class="btn btn-primary btn-sm">
                                <i class="bi bi-pencil-square"></i>
                              </button>
                            </a>
                            <a href="<?php echo base_url();?>admin/datauser?id=<?= $dtForeach->UserID;?>">
                              <button type="button" title="View Detail" class="btn btn-secondary btn-sm">
                                <i class="bi bi-list"></i>
                              </button>
                            </a>
                          </td>
                      </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="modal fade" id="addUser" tabindex="-1">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <form action="<?= base_url();?>admin/simpan_akses" method="post">
                      <div class="modal-header">
                        <h5 class="modal-title">Tambah User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Email</label>
                          <div class="col-sm-8">
                            <input type="hidden" name="table" value="master_user">
                            <input type="email" name="UserID" placeholder="valid email address" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Password</label>
                          <div class="col-sm-8">
                            <input type="password" name="Password" value="" placeholder="password" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Password Confirmation</label>
                          <div class="col-sm-8">
                            <input type="password" name="PasswordConfirm" value="" placeholder="password confirmation" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Nama User</label>
                          <div class="col-sm-8">
                            <input type="text" name="NamaUser" value="" placeholder="Nama Lengkap dan Gelar" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">User Group</label>
                          <div class="col-sm-6">
                            <select class="form-select" aria-label="Default select example" name="UserGroupID" required>
                              <option value="" selected="">Pilih user group</option>
                              <?php foreach ($UserGroup->result() as $dtug) {
                                if($dtug->NA == 'N') echo "<option value='".$dtug->UserGroupID."'>".$dtug->NamaUserGroup."</option>";
                              } ?>
                            </select>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">DokterID</label>
                          <div class="col-sm-8">
                            <input type="text" name="DokterID" value="" placeholder="Khusus dokter diisi DokterID" class="form-control" id="inputText">
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" value="Simpan">
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- UserGroup -->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h2 class="card-title">Data User Group</h2>
              <form>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"><button data-bs-toggle="modal" data-bs-target="#addUserGroup" type="button" class="btn btn-info btn-sm"><i class="bi bi-plus"></i> Usergroup</button></label>
                </div>
              </form>
              <hr>
              <div class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns">
                <div class="datatable-top">
                  <table class="table datatable datatable-table">
                    <thead>
                      <tr>
                        <th>UserGroupID</th>
                        <th>Nama UserGroup</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($UserGroup->result() as $dtForeach) { ?>
                      <tr>
                        <td><?= $dtForeach->UserGroupID;?></td>
                        <td><?= $dtForeach->NamaUserGroup;?></td>
                        <td>
                          <?php if($dtForeach->NA =='Y') {?>
                            <span class="badge bg-secondary">Not Active</span>
                          <?php } ?>
                          <?php if($dtForeach->NA =='N') {?>
                            <span class="badge bg-info">Active</span>
                          <?php } ?>  
                          </td>
                        <td>
                            <a href="<?php echo base_url();?>admin/edituser?id=<?= $dtForeach->UserGroupID;?>">
                              <button type="button" title="Edit data Dokter" class="btn btn-primary btn-sm">
                                <i class="bi bi-pencil-square"></i>
                              </button>
                            </a>
                            <a href="<?php echo base_url();?>admin/datauser?id=<?= $dtForeach->UserGroupID;?>">
                              <button type="button" title="View Detail" class="btn btn-secondary btn-sm">
                                <i class="bi bi-list"></i>
                              </button>
                            </a>
                          </td>
                      </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="modal fade" id="addUserGroup" tabindex="-1">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <form action="<?= base_url();?>admin/simpan_akses" method="post">
                      <div class="modal-header">
                        <h5 class="modal-title">Tambah User Group</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">User Group ID</label>
                          <div class="col-sm-8">
                            <input type="hidden" name="table" value="master_usergroup">
                            <input type="text" name="UserGroupID" placeholder="2 digit huruf kapital" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Nama User Group</label>
                          <div class="col-sm-8">
                            <input type="text" name="NamaUserGroup" value="" placeholder="Nama User Group" class="form-control" id="inputText" required>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" value="Simpan">
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Module -->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h2 class="card-title">Data Module</h2>
              <form>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"><button data-bs-toggle="modal" data-bs-target="#addModule" type="button" class="btn btn-info btn-sm"><i class="bi bi-plus"></i> Module</button></label>
                </div>
              </form>
              <hr>
              <div class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns">
                <div class="datatable-top">
                  <table class="table datatable datatable-table">
                    <thead>
                      <tr>
                        <th>Module ID</th>
                        <th>Nama Modul</th>
                        <th>Url Module</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($Module->result() as $dtForeach) { ?>
                      <tr>
                        <td><?= $dtForeach->ModuleID;?></td>
                        <td><?= $dtForeach->NamaModule;?></td>
                        <td><?= $dtForeach->UrlModule;?></td>
                        <td>
                          <?php if($dtForeach->NA =='Y') {?>
                            <span class="badge bg-secondary">Not Active</span>
                          <?php } ?>
                          <?php if($dtForeach->NA =='N') {?>
                            <span class="badge bg-info">Active</span>
                          <?php } ?>  
                          </td>
                        <td>
                            <a href="<?php echo base_url();?>admin/edituser?id=<?= $dtForeach->ModuleID;?>">
                              <button type="button" title="Edit data Dokter" class="btn btn-primary btn-sm">
                                <i class="bi bi-pencil-square"></i>
                              </button>
                            </a>
                            <a href="<?php echo base_url();?>admin/datauser?id=<?= $dtForeach->ModuleID;?>">
                              <button type="button" title="View Detail" class="btn btn-secondary btn-sm">
                                <i class="bi bi-list"></i>
                              </button>
                            </a>
                          </td>
                      </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="modal fade" id="addModule" tabindex="-1">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <form action="<?= base_url();?>admin/simpan_akses" method="post">
                      <div class="modal-header">
                        <h5 class="modal-title">Tambah User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Module ID</label>
                          <div class="col-sm-8">
                            <input type="hidden" name="table" value="master_module">
                            <input type="text" name="ModuleID" placeholder="huruf kecil tanpa spasi disesuaikan controller" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Nama Module</label>
                          <div class="col-sm-8">
                            <input type="text" name="NamaModule" value="" placeholder="Nama Module tampil di menu sidebar" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Icon</label>
                          <div class="col-sm-8">
                            <input type="text" name="Icon" value="" placeholder="Ambil dari bootstap icon" class="form-control" id="inputText" required>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-3 col-form-label">Url Module</label>
                          <div class="col-sm-8">
                            <input type="text" name="UrlModule" value="" placeholder="disesuaikan dengan controller_name/function" class="form-control" id="inputText" required>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" value="Simpan">
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Hak Akses -->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h2 class="card-title">Hak Akses</h2>
              <form>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"><button data-bs-toggle="modal" data-bs-target="#addHakAkses" type="button" class="btn btn-info btn-sm"><i class="bi bi-plus"></i> Hak Akses</button></label>
                </div>
              </form>
              <hr>
              <div class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns">
                <div class="datatable-top">
                  <table class="table datatable datatable-table">
                    <thead>
                      <tr>
                        <th>Nama Usergroup</th>
                        <th>Nama Module</th>
                        <th>Create</th>
                        <th>Read</th>
                        <th>Update</th>
                        <th>Delete</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($HakAkses->result() as $dtForeach) { ?>
                      <tr>
                        <td><?= $dtForeach->NamaUserGroup;?></td>
                        <td><?= $dtForeach->NamaModule;?></td>
                        <td><?= $dtForeach->C;?></td>
                        <td><?= $dtForeach->R;?></td>
                        <td><?= $dtForeach->U;?></td>
                        <td><?= $dtForeach->D;?></td>
                        <td>
                          <?php if($dtForeach->Status =='Y') {?>
                            <span class="badge bg-secondary">Not Active</span>
                          <?php } ?>
                          <?php if($dtForeach->Status =='N') {?>
                            <span class="badge bg-info">Active</span>
                          <?php } ?>  
                          </td>
                        <td>
                            <a href="<?php echo base_url();?>admin/edituser?id=<?= $dtForeach->HakAksesID;?>">
                              <button type="button" title="Edit data Dokter" class="btn btn-primary btn-sm">
                                <i class="bi bi-pencil-square"></i>
                              </button>
                            </a>
                            <a href="<?php echo base_url();?>admin/datauser?id=<?= $dtForeach->HakAksesID;?>">
                              <button type="button" title="View Detail" class="btn btn-secondary btn-sm">
                                <i class="bi bi-list"></i>
                              </button>
                            </a>
                          </td>
                      </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="modal fade" id="addHakAkses" tabindex="-1">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <form action="<?= base_url();?>admin/simpan_akses" method="post">
                      <div class="modal-header">
                        <h5 class="modal-title">Tambah Hak Akses</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-2 col-form-label">User Group</label>
                          <div class="col-sm-6">
                            <input type="hidden" name="table" value="master_hak_akses">
                            <select class="form-select" id="usergroup" name="usergroup" required>
                              <option value="" selected="">Pilih user group</option>
                              <?php foreach ($UserGroup->result() as $dtug) {
                                if($dtug->NA == 'N') echo "<option value='".$dtug->UserGroupID."'>".$dtug->NamaUserGroup."</option>";
                              } ?>
                            </select>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label for="inputEmail3" class="col-sm-2 col-form-label">Module</label>
                          <div class="col-sm-8">
                            <select id="module" class="form-select" name="module" required>
                            </select>
                          </div>
                        </div>
                        <fieldset class="row mb-3">
                          <legend class="col-form-label col-sm-2 pt-0">Create</legend>
                          <div class="col-sm-10">
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="C" id="gridRadios1" value="Y" required="">
                              <label class="form-check-label" for="gridRadios1">Ya</label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="C" id="gridRadios1" value="N" required="">
                              <label class="form-check-label" for="gridRadios1">Tidak</label>
                            </div>
                          </div>
                        </fieldset>
                        <fieldset class="row mb-3">
                          <legend class="col-form-label col-sm-2 pt-0">Read</legend>
                          <div class="col-sm-10">
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="R" id="gridRadios1" value="Y" required="">
                              <label class="form-check-label" for="gridRadios1">Ya</label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="R" id="gridRadios1" value="N" required="">
                              <label class="form-check-label" for="gridRadios1">Tidak</label>
                            </div>
                          </div>
                        </fieldset>
                        <fieldset class="row mb-3">
                          <legend class="col-form-label col-sm-2 pt-0">Update</legend>
                          <div class="col-sm-10">
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="U" id="gridRadios1" value="Y" required="">
                              <label class="form-check-label" for="gridRadios1">Ya</label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="U" id="gridRadios1" value="N" required="">
                              <label class="form-check-label" for="gridRadios1">Tidak</label>
                            </div>
                          </div>
                        </fieldset>
                        <fieldset class="row mb-3">
                          <legend class="col-form-label col-sm-2 pt-0">Delete</legend>
                          <div class="col-sm-10">
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="D" id="gridRadios1" value="Y" required="">
                              <label class="form-check-label" for="gridRadios1">Ya</label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="D" id="gridRadios1" value="N" required="">
                              <label class="form-check-label" for="gridRadios1">Tidak</label>
                            </div>
                          </div>
                        </fieldset>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" value="Simpan">
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      Copyright <?php echo $config->CopyrightYear;?> <strong><span><?php echo $config->UserOrganization;?></span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="<?php echo $config->DeveloperWeb;?>"><?php echo $config->Developer;?></a>
    </div>
  </footer><!-- End Footer --><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url() ?>assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/chart.js/chart.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/echarts/echarts.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/quill/quill.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="<?php echo base_url() ?>assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url() ?>assets/js/main.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>assets/js/signature.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>assets/js/jquery.min.js"></script>
  <script>
    var wrapper = document.getElementById("signature-pad");
    var clearButton = wrapper.querySelector("[data-action=clear]");
    var savePNGButton = wrapper.querySelector("[data-action=save-png]");
    var canvas = wrapper.querySelector("canvas");
    var el_note = document.getElementById("note");
    var signaturePad;
    signaturePad = new SignaturePad(canvas);
    clearButton.addEventListener("click", function (event) {
      document.getElementById("note").innerHTML="The signature should be inside box";
      signaturePad.clear();
    });
    savePNGButton.addEventListener("click", function (event){
      if (signaturePad.isEmpty()){
        alert("Please provide signature first.");
        event.preventDefault();
      }else{
        var canvas  = document.getElementById("the_canvas");
        var dataUrl = canvas.toDataURL();
        document.getElementById("signature").value = dataUrl;
      }
    });
    function my_function(){
      document.getElementById("note").innerHTML="";
    }
</script>
<script type="text/javascript">
  $(document).ready(function(){ // Ketika halaman sudah siap (sudah selesai di load)
  // Kita sembunyikan dulu untuk loadingnya
  $("#loading").hide();
  
  $("#usergroup").change(function(){ // Ketika user mengganti atau memilih data provinsi
    $("#module").hide(); // Sembunyikan dulu combobox kota nya
    $("#loading").show(); // Tampilkan loadingnya
  
    $.ajax({
      type: "POST", // Method pengiriman data bisa dengan GET atau POST
      url: "<?= base_url();?>admin/getModulesByUsergroup", // Isi dengan url/path file php yang dituju
      data: {usergroup : $("#usergroup").val()}, // data yang akan dikirim ke file yang dituju
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){ // Ketika proses pengiriman berhasil
        $("#loading").hide(); // Sembunyikan loadingnya

        // set isi dari combobox kota
        // lalu munculkan kembali combobox kotanya
        $("#module").html(response.data_module).show();
      },
      error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
        alert(thrownError); // Munculkan alert error
      }
    });
    });
});
</script>

</body>

</html>