<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Your Page Title</title>
</head>
<body>

<table border='1'>
    <tr>
        <th>ID</th>
        <th>Is Stable</th>
        <th>Last Update</th>
        <th>Study Date</th>
        <th>Study Description</th>
        <th>Study Instance UID</th>
        <th>Study Time</th>
        <th>Modified From</th>
        <th>Parent Patient</th>
        <th>Patient ID</th>
        <th>Patient Name</th>
        <th>Series</th>
        <th>Type</th>
    </tr>

    <?php foreach ($studies as $jsonString): ?>
        <?php
        $decodedData = json_decode($jsonString, true);
        ?>
        <tr>
            <td><?= $decodedData['ID'] ?></td>
            <td><?= $decodedData['IsStable'] ?></td>
            <td><?= $decodedData['LastUpdate'] ?></td>
            <td><?= $decodedData['MainDicomTags']['StudyDate'] ?></td>
            <td><?= $decodedData['MainDicomTags']['StudyDescription'] ?? null;?></td>
            <td><?= $decodedData['MainDicomTags']['StudyInstanceUID'] ?></td>
            <td><?= $decodedData['MainDicomTags']['StudyTime'] ?></td>
            <td><?= $decodedData['ModifiedFrom'] ?></td>
            <td><?= $decodedData['ParentPatient'] ?></td>
            <td><?= $decodedData['PatientMainDicomTags']['PatientID'] ?></td>
            <td><?= $decodedData['PatientMainDicomTags']['PatientName'] ?></td>
            <td><?= count($decodedData['Series'])."--".implode(', ', $decodedData['Series']) ?></td>
            <td><?= $decodedData['Type'] ?></td>
        </tr>
    <?php endforeach; ?>

</table>

</body>
</html>
