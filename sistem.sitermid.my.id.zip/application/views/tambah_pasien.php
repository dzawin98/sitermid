<!DOCTYPE html>
<html>
<head>
    <title>Input Data Pasien</title>
</head>
<body>

    <h2>Form Input Data Pasien</h2>

    <?php echo validation_errors(); ?>

    <?php echo form_open('pasien/simpan'); ?>

    <label for="nama">Nama:</label>
    <input type="text" name="nama" value="<?php echo set_value('nama'); ?>"><br>

    <label for="no_rm">Nomor RM:</label>
    <input type="text" name="no_rm" value="<?php echo set_value('no_rm'); ?>"><br>

    <label for="tanggal_lahir">Tanggal Lahir:</label>
    <input type="date" name="tanggal_lahir" value="<?php echo set_value('tanggal_lahir'); ?>"><br>

    <label for="jenis_kelamin">Jenis Kelamin:</label>
    <select name="jenis_kelamin">
        <option value="Laki-laki" <?php echo set_select('jenis_kelamin', 'Laki-laki'); ?>>Laki-laki</option>
        <option value="Perempuan" <?php echo set_select('jenis_kelamin', 'Perempuan'); ?>>Perempuan</option>
    </select><br>

    <label for="alamat">Alamat:</label>
    <textarea name="alamat"><?php echo set_value('alamat'); ?></textarea><br>

    <input type="submit" name="submit" value="Simpan Data Pasien">

    <?php echo form_close(); ?>

</body>
</html>
