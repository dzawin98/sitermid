<?php
class Auth extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('m_auth');
        $this->load->model('m_config');
    }
 
    function index(){
        $data['config'] = $this->m_config->config();
        $this->load->view('v_login',$data);
    }
 
    function login(){
        $user       = $this->input->post('username');
        $username   = $this->db->escape_str($user);
        $pwd        = $this->input->post('password');
        $password   = $this->db->escape_str($pwd);
        
        
        $cek_login=$this->m_auth->login($username,$password);

        if($cek_login->num_rows() == 1){ //jika login sebagai ipcn
            $data=$cek_login->row_array();
            if($data['DokterID'] !='') {
                $dokterid = $data['DokterID'];
                $data_dokter = $this->m_auth->get_dokter($dokterid)->row_array();
                $this->session->set_userdata('DokterID', $dokterid);
                $this->session->set_userdata('NamaDokter',$data_dokter['NamaDokter']);
            }
            $this->session->set_userdata('login',TRUE);
            $this->session->set_userdata('UserGroupID',$data['UserGroupID']);
            $this->session->set_userdata('NamaUserGroup',$data['NamaUserGroup']);
            $this->session->set_userdata('UserID',$data['UserID']);
            $this->session->set_userdata('NamaUser',$data['NamaUser']);
            $this->session->set_userdata('Foto',$data['Foto']);
            $this->session->set_userdata('InstitusiID',$data['InstitusiID']);
            $this->session->set_userdata('NamaInstitusi',$data['NamaInstitusi']);
            //echo $this->session->userdata('NamaInstitusi');
            redirect('admin');
        }
        else {
            redirect('auth');
            //echo $username." ".$password;
        }
 
    }
 
    function logout(){
        $this->session->sess_destroy();
        redirect('auth');
    }
 
}