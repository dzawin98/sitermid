<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set("Asia/Jakarta");

class Admin extends CI_Controller {

	var $data;

	function __construct(){
		parent::__construct();
    	if($this->session->userdata('login') != TRUE){
            redirect('auth');
        } else {
        	$usergroupid = $this->session->userdata('UserGroupID');
        	$this->load->model('m_config');
        	$this->load->model('m_admin');
    		$this->load->library('upload');
            $this->load->helper('date');
        	$this->data = array(
        		'config'	=> $this->m_config->config(),
        		'menu'	    => $this->m_admin->get_menu($usergroupid),
        	);
    	}
    
  	}

	function index() {
		$data = $this->data;
        $data['active'] = "dashboard";
        //$data['toggle'] = "on";

        $data['trx_study'] = $this->m_admin->get_trx_study();

        $pacs = $this->m_admin->get_pacs_server()->row_array();
        $serverURL = $pacs['ServerURL'];
        $data['serverURL'] = $serverURL;

        $get_study_stored = array_map(function($item) {
            return $item->StudyID;
        }, $this->m_admin->get_study_stored()->result());

        if($get_study_stored === null)
            $b = array('data'=>0);
        else $b = $get_study_stored;

        $a = $this->curl->simple_get($serverURL.'studies');
        $decodedData = json_decode($a);
        if ($decodedData === null && json_last_error() !== JSON_ERROR_NONE) {
            echo "<script>alert('Tidak dapat terkoneksi dengan Server PACS!');window.location.href='".base_url()."admin/pacs';</script>";
        } else {
            $data['studies'] = [];
            $ab = array_diff($decodedData, $b);
            $data['unassign'] = count($ab);
            $data['assign'] = $this->m_admin->get_study_stored()->num_rows();

            if ($this->session->userdata('UserGroupID') == 'DS'){
                $DokterID = $this->session->userdata('DokterID');
                $data['noexpertise'] = $this->m_admin->get_jumlah_expertise(0,$DokterID)->row();
                $data['unverified'] = $this->m_admin->get_jumlah_expertise(1,$DokterID)->row();
                $data['verified'] = $this->m_admin->get_jumlah_expertise(2,$DokterID)->row();
            } else {
                $data['noexpertise'] = $this->m_admin->get_jumlah_all_expertise(0)->row();
                $data['unverified'] = $this->m_admin->get_jumlah_all_expertise(1)->row();
                $data['verified'] = $this->m_admin->get_jumlah_all_expertise(2)->row();
            }    
        }

        
		$this->load->view('admin/v_header',$data);
		$this->load->view('admin/dashboard/v_dashboard',$data);
	}

    function pasien() {
        $moduleid = "pasien";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "pasien";
            $data['Dokter'] = $this->m_admin->get_dokter_rad();
            $data['trx_study'] = $this->m_admin->get_trx_study();

            $pacs = $this->m_admin->get_pacs_server()->row_array();
            $serverURL = $pacs['ServerURL'];
            $data['serverURL'] = $serverURL;

            $get_study_stored = array_map(function($item) {
                    return $item->StudyID;
                }, $this->m_admin->get_study_stored()->result());

            if($get_study_stored === null)
                $b = array('data'=>0);
            else $b = $get_study_stored;

            //var_dump($b);

            $a = $this->curl->simple_get($serverURL.'studies');
            $decodedData = json_decode($a);
            if ($decodedData === null && json_last_error() !== JSON_ERROR_NONE) {
                echo "<script>alert('Tidak dapat terkoneksi dengan Server PACS!');window.location.href='".base_url()."admin/pacs';</script>";
            } else {
                $data['studies'] = [];
                $ab = array_diff($decodedData, $b);
                foreach ($ab as $value) {
                    $data['studies'][] = $this->curl->simple_get($serverURL.'studies/'.$value);
                }
                
                //$this->load->view('your_view', $data);
                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/pasien/v_pasien.php',$data);
            
            }
        }
    }

    function set_radiologist() {
        $data = array(
            'StudyID' => $this->input->post('StudyID'),
            'StudyUID' => $this->input->post('StudyUID'),
            'MR' => $this->input->post('MR'),
            'Pasien' => $this->input->post('Pasien'),
            'TglLahir' => $this->input->post('TglLahir'),
            'Deskripsi' => $this->input->post('Deskripsi'),
            'TglPemeriksaan' => $this->input->post('TglPemeriksaan'),
            'Modalitas' => $this->input->post('Modalitas'),
            'AccNo' => $this->input->post('AccNo'),
            'DokterID' => $this->input->post('DokterID'),
            'Status' => 0,
            'NA' => 'N',
            'LoginBuat' => $this->session->userdata('UserID'),
            'TanggalBuat' => date('Y-m-d H:i:s', now())
        );
        $tabel = 'trx_study';
        $this->m_admin->simpan_data($tabel,$data);
        echo "<script>alert('Data berhasil disimpan!');window.location.href='".base_url()."admin/pasien';</script>";
    }

    function edit_radiologist() {
        $field_id ="StudyID";
        $id = $this->input->post('StudyID');
        $data = array(
            'DokterID' => $this->input->post('DokterID'),
            'LoginEdit' => $this->session->userdata('UserID'),
            'TanggalEdit' => date('Y-m-d H:i:s', now())
        );
        $table = 'trx_study';
        $cek_status_expertise = $this->m_admin->get_status_expertise($id);
        $status = $cek_status_expertise->Status;
        if($status == 0) {
            $this->m_admin->update_data($table, $field_id, $id, $data);
            echo "<script>alert('Data berhasil disimpan!');window.location.href='".base_url()."admin/pasien';</script>";
        } else {
            echo "<script>alert('Data Dokter Tidak dapat diubah karena sudah ada expertise!');window.location.href='".base_url()."admin/pasien';</script>";
        }
    }

    function detail() {
        $moduleid = "pasien";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "pasien";
            $StudyID = $this->input->get('StudyID');
            $data['detail_study'] = $this->m_admin->get_detail_study($StudyID);
            $data['detail_expertise'] = $this->m_admin->get_detail_expertise($StudyID);
            $data['trx_expertise'] = $this->m_admin->get_trx_expertise($StudyID);

            $pacs = $this->m_admin->get_pacs_server()->row_array();
            $serverURL = $pacs['ServerURL'];
            $data['serverURL'] = $serverURL;


                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/pasien/v_detail.php',$data);
        }
    }

    function pasienstudy() {
        $moduleid = "pasienstudy";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $DokterID = $this->session->userdata('DokterID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "pasienstudy";
            $data['trx_study'] = $this->m_admin->get_trx_study_bydokter($DokterID);

                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/pasienstudy/v_pasienstudy.php',$data);
        }
    }

    function detailstudy() {
        $moduleid = "pasienstudy";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "pasienstudy";
            $StudyID = $this->input->get('StudyID');
            $data['detail_study'] = $this->m_admin->get_detail_study($StudyID);
            $data['detail_expertise'] = $this->m_admin->get_detail_expertise($StudyID);
            $data['trx_expertise'] = $this->m_admin->get_trx_expertise($StudyID);

            $pacs = $this->m_admin->get_pacs_server()->row_array();
            $serverURL = $pacs['ServerURL'];
            $data['serverURL'] = $serverURL;


                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/pasienstudy/v_detailstudy.php',$data);
        }
    }

    function expertise() {
        $moduleid = "pasienstudy";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        $DokterID = $this->session->userdata('DokterID');
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "pasienstudy";
            $data['toggle'] = "on";
            $StudyID = $this->input->get('id');
            $data['detail_study'] = $this->m_admin->get_detail_study($StudyID);
            $data['detail_expertise'] = $this->m_admin->get_detail_expertise($StudyID);
            $data['trx_expertise'] = $this->m_admin->get_trx_expertise($StudyID);

            $data['template'] = $this->m_admin->get_template($DokterID);

            $pacs = $this->m_admin->get_pacs_server()->row_array();
            $serverURL = $pacs['ServerURL'];
            $data['serverURL'] = $serverURL;


                $this->load->view('admin/v_header_expertise',$data);
                $this->load->view('admin/pasienstudy/v_expertise.php',$data);
        }
    }

    function add_template(){
        $Judul = $this->input->post('Judul');
        $DokterID = $this->input->post('DokterID');
        $template = $this->input->post('content');

        $data = array(
            'JudulTemplate' => $Judul,
            'Text' => $template,
            'DokterID' => $DokterID,
            'NA' => 'N'
        );

        $tabel = 'master_template';
        $this->m_admin->simpan_data($tabel,$data);
        echo "<script>alert('Data berhasil disimpan!');window.history.back();</script>";
    }

     function simpan_expertise() {
        $status = $this->input->post('Status');
        if($status == 0) {
            $data = array(
                'StudyID' => $this->input->post('StudyID'),
                'Expertise' => $this->input->post('content'),
                'DokterID' => $this->input->post('DokterID'),
                'RevisionNo' => 0,
                'Final' => 'Y',
                'NA' => 'N',
                'LoginBuat' => $this->session->userdata('UserID'),
                'TanggalBuat' => date('Y-m-d H:i:s', now())
            );
            $tabel = 'trx_expertise';
            $this->m_admin->simpan_data($tabel,$data);

            $id = $this->input->post('StudyID');
            $field_id = 'StudyID';
            $data2 = array(
                'Status' => 1
            );
            $table2 = 'trx_study';
            $this->m_admin->update_data($table2, $field_id, $id, $data2);
            echo "<script>alert('Data berhasil disimpan!');window.history.back();</script>";
        } else if ($status == 1) {
            $id1 = $this->input->post('ExpertiseID');
            $field_id1 = 'ExpertiseID';
            $data1 = array(
                'Expertise' => $this->input->post('content'),
                'LoginEdit' => $this->session->userdata('UserID'),
                'TanggalEdit' => date('Y-m-d H:i:s', now())
            );
            $table1 = 'trx_expertise';
            $this->m_admin->update_data($table1, $field_id1, $id1, $data1);

            $id3 = $this->input->post('StudyID');
            $field_id3 = 'StudyID';
            $data3 = array(
                'Status' => 2,
            );
            $table3 = 'trx_study';
            $this->m_admin->update_data($table3, $field_id3, $id3, $data3);
            echo "<script>alert('Data berhasil disimpan!');window.history.back();</script>";
        }
    }

    function template() {
        $moduleid = "template";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $DokterID = $this->session->userdata('DokterID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "template";
            $data['Templates'] = $this->m_admin->get_all_template($DokterID);

                //$this->load->view('your_view', $data);
                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/template/v_template.php',$data);
        }
    }

    function dokter() {
        $moduleid = "dokter";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "dokter";
            $data['Dokter'] = $this->m_admin->get_all_dokter();
                //$this->load->view('your_view', $data);
                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/dokter/v_dokter.php',$data);
        }
    }

    function datadokter() {
        $moduleid = "dokter";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "dokter";
            $DokterID = $this->input->get('id');
            $data['detail_dokter'] = $this->m_admin->get_detail_dokter($DokterID);


                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/dokter/v_detail_dokter.php',$data);
        }
    }

    function editdokter() {
        $moduleid = "dokter";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "dokter";
            $DokterID = $this->input->get('id');
            $data['detail_dokter'] = $this->m_admin->get_detail_dokter($DokterID);


                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/dokter/v_edit_dokter.php',$data);
        }
    }

    function simpan_edit_dokter() {
        $field_id ="DokterID";
        $id = $this->input->post('DokterID');
        $data = array(
            'NamaDokter' => $this->input->post('NamaDokter'),
            'NIK' => $this->input->post('NIK'),
            'NoSIP' => $this->input->post('DokterID'),
            'SIPDateActive' => $this->input->post('SIPDateActive'),
            'LoginEdit' => $this->session->userdata('UserID'),
            'TanggalEdit' => date('Y-m-d H:i:s', now()),
            'NA' => $this->input->post('NA')         
        );
        $table = 'master_dokter';
        $this->m_admin->update_data($table, $field_id, $id, $data);
        echo "<script>alert('Data berhasil disimpan!');window.location.href='".base_url()."admin/dokter';</script>";
    }

    function simpan_dokter() {
        $id = $this->input->post('DokterID');
        $field_id = "DokterID";
        $data = array(
            'DokterID'  => $id,
            'NamaDokter' => $this->input->post('NamaDokter'),
            'NIK' => $this->input->post('NIK'),
            'NoSIP' => $this->input->post('DokterID'),
            'SIPDateActive' => $this->input->post('SIPDateActive'),
            'SIPDateExpired' => $this->input->post('SIPDateExpired'),
            'LoginBuat' => $this->session->userdata('UserID'),
            'TanggalBuat' => date('Y-m-d H:i:s', now()),
            'NA' => $this->input->post('NA')         
        );
        $table = 'master_dokter';
        $cek_duplikasi = $this->m_admin->cek_duplikasi($id, $field_id, $table);
        if($cek_duplikasi == null) {
            $this->m_admin->simpan_data($table, $data);
            echo "<script>alert('Data berhasil disimpan!');window.location.href='".base_url()."admin/dokter';</script>";
        } else {
            echo "<script>alert('DokterID sudah Ada. Silakan gunakan kode lain!');window.history.back();</script>";
        }
    }

    function akses() {
        $moduleid = "akses";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "akses";
            $data['User'] = $this->m_admin->get_all_user();
            $data['UserGroup'] = $this->m_admin->get_all_usergroup();
            $data['Module'] = $this->m_admin->get_all_module();
            $data['HakAkses'] = $this->m_admin->get_all_hakakses();
                //$this->load->view('your_view', $data);
                $this->load->view('admin/v_header',$data);
                $this->load->view('admin/akses/v_akses.php',$data);
        }
    }

    function simpan_akses() {
        $table = $this->input->post('table');
        if($table == "master_user") {
            $password = md5($this->input->post('Password'));
            $passconfirm = md5($this->input->post('PasswordConfirm'));
            if($password == $passconfirm) {
                $id = $this->input->post('UserID');
                $field_id = "UserID";
                $data = array(
                    'UserID'  => $id,
                    'NamaUser' => $this->input->post('NamaUser'),
                    'Password' => $password,
                    'UserGroupID' => $this->input->post('UserGroupID'),
                    'DokterID' => $this->input->post('DokterID') ?? null,
                    'Foto' => 'assets/img/profil/default.png',
                    'LoginBuat' => $this->session->userdata('UserID'),
                    'TanggalBuat' => date('Y-m-d H:i:s', now()),
                    'NA' => 'N',
                    'InstitusiID' => $this->session->userdata('InstitusiID')         
                );
            } else {
                echo "<script>alert('Password confirm tidak sama!');window.history.back();</script>";
            }
        } else if($table == "master_usergroup"){
            $id = $this->input->post('UserGroupID');
            $field_id = 'UserGroupID';
            $data = array(
                'UserGroupID' => $id,
                'NamaUserGroup' => $this->input->post('NamaUserGroup'),
                'NA' => 'N'
            );
        } else if($table == "master_module") {
            $id = $this->input->post('ModuleID');
            $field_id = 'ModuleID';
            $data = array(
                'ModuleID' => $id,
                'NamaModule' => $this->input->post('NamaModule'),
                'Icon' => $this->input->post('Icon'),
                'UrlModule' =>$this->input->post('UrlModule'),
                'NA' => 'N'
            );
        } else if($table == "master_hak_akses"){
            $id = null;
            $field_id = 'HakAksesID';
            $data = array(
                'UserGroupID' => $this->input->post('usergroup'),
                'ModuleID' => $this->input->post('module'),
                'C' => $this->input->post('C'),
                'R' => $this->input->post('R'),
                'U' => $this->input->post('U'),
                'D' => $this->input->post('D'),
                'NA' => 'N'
            );
        }

        $cek_duplikasi = $this->m_admin->cek_duplikasi($id, $field_id, $table);
        if($cek_duplikasi == null) {
            $this->m_admin->simpan_data($table, $data);
            echo "<script>alert('Data berhasil disimpan!');window.location.href='".base_url()."admin/akses';</script>";
        } else {
            echo "<script>alert('DokterID sudah Ada. Silakan gunakan kode lain!');window.history.back();</script>";
        }
    }

    function getModulesByUsergroup(){
        $usergroup = $this->input->post('usergroup');

        // Load modules not already in accessrole for the selected usergroup
        $modules = $this->m_admin->getModulesNotInAccessRole($usergroup);

        $html = "<option value=''>Pilih Module</option>";

        foreach ($modules->result() as $data_modules) {
            $html .= "<option value='".$data_modules->ModuleID."'>".$data_modules->NamaModule."</option>";
        }
        $callback = array('data_module'=>$html);
        echo json_encode($callback);
        // Return modules as JSON
        //$this->output->set_content_type('application/json')->set_output(json_encode($modules));
    }

    function pacs() {
        $moduleid = "pacs";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "pacs";
            $pacs = $this->m_admin->get_pacs_server()->row();
            $data['ServerID'] = $pacs->ServerID;
            $data['ServerName'] = $pacs->ServerName;
            $data['ServerURL'] = $pacs->ServerURL;
            $data['NA'] = $pacs->NA;
            $url_pacs = $pacs->ServerURL;
            $a = $this->curl->simple_get($url_pacs.'studies');
            $decodedData = json_decode($a);
            if ($decodedData === null && json_last_error() !== JSON_ERROR_NONE) {
                $data['connection'] = 0;
            } else {
                $data['connection'] = 1;
            }

            $this->load->view('admin/v_header',$data);
            $this->load->view('admin/pacs/v_pacs.php',$data);
        }
    }

    function edit_pacs() {
        $field_id ="ServerID";
        $id = $this->input->post('ServerID');
        $data = array(
            'ServerID' => $this->input->post('ServerID'),
            'ServerName' => $this->input->post('ServerName'),
            'ServerURL' => $this->input->post('ServerURL'),
        );
        $table = 'pacs_server';
        $this->m_admin->update_data($table, $field_id, $id, $data);
        echo "<script>alert('Data berhasil disimpan!');window.location.href='".base_url()."admin/pacs';</script>";
    }

    function institusi() {
        $moduleid = "institusi";
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        $cek_akses = $this->m_admin->cek_akses($usergroupid,$moduleid);
        if($cek_akses->num_rows() != 1){
            echo "<script>alert('Anda tidak memiliki akses ke module ini!');window.location.href='".base_url()."admin';</script>";
        } else {
            $data = $this->data;
            $data['module_detail'] = $cek_akses->row()->NamaModule;
            $data['C'] = $cek_akses->row()->C;
            $data['R'] = $cek_akses->row()->R;
            $data['U'] = $cek_akses->row()->U;
            $data['D'] = $cek_akses->row()->D;

            $data['active'] = "institusi";
            $data['institusi'] = $this->m_admin->get_institusi($InstitusiID)->row();
            
            $this->load->view('admin/v_header',$data);
            $this->load->view('admin/institusi/v_institusi.php',$data);
        }
    }

    function edit_institusi() {
        $field_id ="InstitusiID";
        $id = $this->input->post('InstitusiID');
        $data = array(
            'InstitusiID' => $this->input->post('InstitusiID'),
            'NamaInstitusi' => $this->input->post('NamaInstitusi'),
            'Alamat' => $this->input->post('Alamat'),
            'NomorTelp' => $this->input->post('NomorTelp'),
            'KodePos' => $this->input->post('KodePos'),
        );
        $table = 'master_institusi';
        $this->m_admin->update_data($table, $field_id, $id, $data);
        echo "<script>alert('Data berhasil disimpan!');window.location.href='".base_url()."admin/institusi';</script>";
    }


	function cetak_expertise() {
        $usergroupid = $this->session->userdata('UserGroupID');
        $InstitusiID = $this->session->userdata('InstitusiID');
        
            $data = $this->data;

            $data['active'] = "pasienstudy";
            $StudyID = $this->input->get('StudyID');
            $data['detail_study'] = $this->m_admin->get_detail_study($StudyID);
            $data['detail_expertise'] = $this->m_admin->get_detail_expertise($StudyID);
            $data['trx_expertise'] = $this->m_admin->get_trx_expertise($StudyID);

            $pacs = $this->m_admin->get_pacs_server()->row_array();
            $serverURL = $pacs['ServerURL'];
            $data['serverURL'] = $serverURL;

            $data['detail_institusi'] = $this->m_admin->getDataInstitusi($InstitusiID);


            $this->load->library('pdfgenerator');
            $data['title_pdf'] = 'Hasil Expertise';
            $file_pdf = 'Hasil Expertise';
            $paper = 'A4';
            $orientation = "portrait";

            $html = $this->load->view('admin/pasienstudy/v_cetak_expertise',$data, true);
            $this->pdfgenerator->generate($html, $file_pdf,$paper,$orientation);
	}
}

