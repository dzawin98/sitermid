<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Pasien_model');
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('form_validation');
    }

    // Fungsi untuk menampilkan form input data pasien
    public function tambah() {
        $this->load->view('tambah_pasien');
    }

    // Fungsi untuk memproses data input pasien
    public function simpan() {
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('no_rm', 'Nomor RM', 'required');
        $this->form_validation->set_rules('tanggal_lahir', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if ($this->form_validation->run() == FALSE) {
            // Jika validasi gagal, tampilkan kembali form dengan pesan error
            $this->load->view('tambah_pasien');
        } else {
            // Jika validasi berhasil, simpan data ke database
            $data = array(
                'nama' => $this->input->post('nama'),
                'no_rm' => $this->input->post('no_rm'),
                'tanggal_lahir' => $this->input->post('tanggal_lahir'),
                'jenis_kelamin' => $this->input->post('jenis_kelamin'),
                'alamat' => $this->input->post('alamat')
            );
            $this->Pasien_model->tambah_pasien($data);
            redirect('pasien/tambah');
        }
    }
}
