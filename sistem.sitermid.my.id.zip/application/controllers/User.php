<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model('m_config');
    }

	public function index() {
		$data['config'] = $this->m_config->config();
		$this->load->view('user/v_user',$data);
	}
}
