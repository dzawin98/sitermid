<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Studies extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Orthanc_model');
    }

    public function index() {
    $studyIDs = $this->Orthanc_model->getStudyIDs();

    $studies = array();

    foreach ($studyIDs as $studyID) {
        $studyDetails = $this->Orthanc_model->getStudyDetails($studyID);

        // Check if $studyDetails is an array before adding it to $studies
        if (is_array($studyDetails) && !empty($studyDetails)) {
            $studies[] = $studyDetails;
        }
    }

    $data['studies'] = $studies;
    $this->load->view('studies_list', $data);
}

}
